import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

// Google AI Studio injects the Gemini key as process.env.API_KEY.
// Locally, put GEMINI_API_KEY=... in .env.local (see .env.local.example).
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, '.', '');
  const key = env.GEMINI_API_KEY ?? env.API_KEY ?? '';
  return {
    plugins: [react(), tailwindcss()],
    define: {
      'process.env.API_KEY': JSON.stringify(key),
      'process.env.GEMINI_API_KEY': JSON.stringify(key),
    },
    server: { port: 3000, host: '0.0.0.0' },
  };
});
