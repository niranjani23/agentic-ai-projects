import { GoogleGenAI, Type } from '@google/genai';
import type { Capabilities, Hint, HintRequest, LearnerMemory } from './types';
import { buildSystemPrompt, buildUserPrompt, HINT_SCHEMA_DESCRIPTION } from './prompts';

const MODEL = 'gemini-2.5-flash';

function apiKey(): string {
  return (process.env.API_KEY || process.env.GEMINI_API_KEY || '').trim();
}

export function geminiAvailable(): boolean {
  return apiKey().length > 0;
}

/** Fallback so the demo never dead-ends if the key or network is missing. */
const OFFLINE: Record<HintRequest['stop'], Record<Capabilities['tutorMode'], string>> = {
  wire: {
    voice: 'Uh oh, that one is a blocker! Try the shiny orange copper.',
    guided: 'Rubber is like a closed door in a hallway: the electron bumps into it and stops. Which material feels most like an open door? Try a shiny metal.',
    open: 'Insulators have almost no free electrons, so charge cannot move through them. Pick conductors and keep the series sum of resistances under the target: R_total = R1 + R2 + R3.',
  },
  switch: {
    voice: 'The loop is still open! Close the switch so the electron can go all the way around.',
    guided: 'Think of a slide with a gap in the middle: nobody reaches the bottom. Which switch is still leaving a gap in the loop?',
    open: 'Current needs a continuous closed path. S1 is in series, so it must be closed; S2 and S3 are parallel, so one of them is enough. What is the minimum set?',
  },
  lamp: {
    voice: 'Hmm, the light is not happy. Try the middle one, not too much, not too little.',
    guided: 'Resistance is like a narrow pipe: too narrow and only a trickle gets through, too wide and it floods. Nudge the slider toward the middle and watch the glow.',
    open: 'Use V = I × R. With 12 V and a target current of 0.5 A, what resistance do you need? Check whether your value gives more or less current than that.',
  },
};

export async function getHint(req: HintRequest, caps: Capabilities, memory: LearnerMemory): Promise<Hint> {
  const offline: Hint = {
    hint: OFFLINE[req.stop][caps.tutorMode],
    misconception: req.wrongChoice.slice(0, 40),
    followUps: caps.tutorMode === 'voice' ? [] : ['Why does that happen?', 'Show me an example', 'What should I try next?'],
    source: 'offline',
  };
  if (!geminiAvailable()) return offline;

  try {
    const ai = new GoogleGenAI({ apiKey: apiKey() });
    const response = await ai.models.generateContent({
      model: MODEL,
      contents: buildUserPrompt(req),
      config: {
        systemInstruction: buildSystemPrompt(caps, memory),
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            hint: { type: Type.STRING, description: HINT_SCHEMA_DESCRIPTION.hint },
            misconception: { type: Type.STRING, description: HINT_SCHEMA_DESCRIPTION.misconception },
            followUps: { type: Type.ARRAY, items: { type: Type.STRING }, description: HINT_SCHEMA_DESCRIPTION.followUps },
          },
          required: ['hint', 'misconception', 'followUps'],
        },
        thinkingConfig: { thinkingBudget: 0 }, // speed over depth: a hint has to feel instant to a kid
        temperature: 0.7,
      },
    });
    const parsed = JSON.parse(response.text ?? '{}') as Partial<Hint>;
    if (!parsed.hint) return offline;
    return {
      hint: parsed.hint,
      misconception: parsed.misconception || offline.misconception,
      followUps: caps.tutorMode === 'voice' ? [] : (parsed.followUps ?? []).slice(0, 3),
      source: 'gemini',
    };
  } catch (err) {
    console.warn('Gemini hint failed, using offline hint', err);
    return offline;
  }
}

/** Browser text-to-speech for the voice persona. Free, instant, nothing leaves the device. */
export function speak(text: string) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.rate = 0.95;
  u.pitch = 1.1;
  window.speechSynthesis.speak(u);
}
