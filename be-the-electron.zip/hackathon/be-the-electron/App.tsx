import { useCallback, useEffect, useRef, useState } from 'react';
import { MockCapabilityProvider } from './capabilities';
import { getHint, speak } from './gemini';
import { CARDS, STOPS, type AgeBand, type Capabilities, type Hint, type LearnerMemory, type Region, type StopId } from './types';
import AgeSwitcher from './components/AgeSwitcher';
import Bedroom from './components/Bedroom';
import Tutor from './components/Tutor';
import WireStop from './components/WireStop';
import SwitchStop from './components/SwitchStop';
import LampStop from './components/LampStop';

interface Progress {
  watts: number;
  cards: StopId[];
  stopIndex: number;
  memory: LearnerMemory;
}

const EMPTY_MEMORY: LearnerMemory = { misconceptionsSeen: [], hintsUsed: 0, stopsCompleted: [] };
const FRESH: Progress = { watts: 0, cards: [], stopIndex: 0, memory: EMPTY_MEMORY };
const STORAGE_KEY = 'be-the-electron:v1';

function loadProgress(): Progress {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? { ...FRESH, ...JSON.parse(raw) } : FRESH;
  } catch {
    return FRESH;
  }
}

export default function App() {
  const [band, setBand] = useState<AgeBand>('5-7');
  const [region, setRegion] = useState<Region>('US');
  const [caps, setCaps] = useState<Capabilities | null>(null);
  const [capsLoading, setCapsLoading] = useState(true);
  const [progress, setProgress] = useState<Progress>(loadProgress);
  const [hint, setHint] = useState<Hint | null>(null);
  const [thinking, setThinking] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const attempts = useRef<Record<string, number>>({});
  const lastWrong = useRef<string>('no mistake yet, just curious');

  // k-ID adapter: the only place the app learns what this player may do.
  useEffect(() => {
    let cancelled = false;
    setCapsLoading(true);
    new MockCapabilityProvider(band, region).getUserCapabilities().then((c) => {
      if (!cancelled) { setCaps(c); setCapsLoading(false); setHint(null); }
    });
    return () => { cancelled = true; };
  }, [band, region]);

  // Persist progress. Under the minimal data policy, the learner profile never touches storage.
  useEffect(() => {
    const toStore = caps?.dataPolicy === 'minimal' ? { ...progress, memory: EMPTY_MEMORY } : progress;
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(toStore)); } catch { /* private mode */ }
  }, [progress, caps]);

  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(() => setToast(null), 2200);
    return () => window.clearTimeout(t);
  }, [toast]);

  const stop = STOPS[progress.stopIndex];
  const finished = !stop;

  const askTutor = useCallback(async (wrongChoice: string, question?: string) => {
    if (!caps || !stop) return;
    setThinking(true);
    const h = await getHint(
      { stop: stop.id, concept: stop.concept, wrongChoice, attempt: attempts.current[stop.id] ?? 1, question },
      caps,
      progress.memory,
    );
    setHint(h);
    setThinking(false);
    if (caps.tutorMode === 'voice') speak(h.hint);
  }, [caps, stop, progress.memory]);

  const onWrong = useCallback((wrongChoice: string, misconception: string) => {
    if (!stop) return;
    attempts.current[stop.id] = (attempts.current[stop.id] ?? 0) + 1;
    lastWrong.current = wrongChoice;
    setProgress((p) => ({
      ...p,
      memory: {
        ...p.memory,
        hintsUsed: p.memory.hintsUsed + 1,
        misconceptionsSeen: p.memory.misconceptionsSeen.includes(misconception) ? p.memory.misconceptionsSeen : [...p.memory.misconceptionsSeen, misconception],
      },
    }));
    void askTutor(wrongChoice);
  }, [stop, askTutor]);

  const onSolve = useCallback(() => {
    if (!stop) return;
    const id = stop.id;
    setProgress((p) => ({
      ...p,
      watts: p.watts + stop.watts,
      cards: p.cards.includes(id) ? p.cards : [...p.cards, id],
      memory: { ...p.memory, stopsCompleted: p.memory.stopsCompleted.includes(id) ? p.memory.stopsCompleted : [...p.memory.stopsCompleted, id] },
    }));
    if (caps?.tutorMode === 'voice') speak(`You did it! The lamp is brighter. You earned the ${CARDS[id].title} card.`);
    setToast(`🎴 New card: ${CARDS[id].title}`);
    window.setTimeout(() => {
      setHint(null);
      setProgress((p) => ({ ...p, stopIndex: p.stopIndex + 1 }));
    }, 1500);
  }, [stop, caps]);

  function restart() {
    attempts.current = {};
    setHint(null);
    setProgress(FRESH);
  }

  function share() {
    if (!caps) return;
    if (caps.sharing === 'parent-approved') setToast('📨 Sent to a parent for approval (k-ID consent flow would open here)');
    else {
      const url = `${location.origin}${location.pathname}?lamp=${progress.watts}&cards=${progress.cards.join(',')}`;
      navigator.clipboard?.writeText(url).catch(() => undefined);
      setToast('🔗 Share link copied');
    }
  }

  return (
    <div className="min-h-screen px-4 py-5 max-w-6xl mx-auto">
      <header className="flex flex-wrap items-end justify-between gap-3 mb-5">
        <div>
          <h1 className="text-3xl font-black tracking-tight">⚡ Be the Electron</h1>
          <p className="text-sm text-slate-400">Same game for everyone. The experience adapts to who is playing.</p>
        </div>
        <button onClick={restart} className="text-xs rounded-md border border-slate-700 px-3 py-1.5 hover:border-slate-500">Restart journey</button>
      </header>

      {/* journey strip */}
      <ol className="flex items-center gap-2 mb-5 text-xs">
        {['Power plant', 'Lines', 'Transformer', 'Outlet'].map((s) => (
          <li key={s} className="rounded-full border border-slate-800 px-2.5 py-1 text-slate-500 line-through decoration-slate-700">{s}</li>
        ))}
        {STOPS.map((s, i) => (
          <li key={s.id} className={`rounded-full px-2.5 py-1 border ${i < progress.stopIndex ? 'border-emerald-700 bg-emerald-900/30 text-emerald-200' : i === progress.stopIndex ? 'border-sky-400 bg-sky-900/40 text-sky-100 font-semibold' : 'border-slate-800 text-slate-500'}`}>
            {i < progress.stopIndex ? '✓ ' : ''}{s.title}
          </li>
        ))}
      </ol>

      <div className="grid gap-5 md:grid-cols-[1.3fr_1fr]">
        <main className="space-y-4">
          <section className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
            {!caps ? (
              <div className="text-slate-400 animate-pulse py-10 text-center">Loading player profile…</div>
            ) : finished ? (
              <div className="text-center py-6">
                <div className="text-5xl mb-3">🌟</div>
                <h2 className="text-2xl font-bold mb-1">You lit the whole room!</h2>
                <p className="text-slate-300 mb-4">Every stop solved. The reading lamp is at full brightness.</p>
                <div className="flex justify-center gap-3 mb-5">
                  {progress.cards.map((id) => <Card key={id} id={id} />)}
                </div>
                <button onClick={restart} className="rounded-xl bg-sky-500 px-5 py-2.5 font-semibold text-slate-950">Play again</button>
              </div>
            ) : (
              <>
                <div className="flex items-baseline justify-between mb-3">
                  <h2 className="text-xl font-bold">Stop {progress.stopIndex + 1}: {stop.title}</h2>
                  <span className="text-xs text-slate-400">{stop.concept}</span>
                </div>
                <div key={`${stop.id}-${caps.inputMode}`}>
                  {stop.id === 'wire' && <WireStop caps={caps} solved={false} onSolve={onSolve} onWrong={onWrong} />}
                  {stop.id === 'switch' && <SwitchStop caps={caps} solved={false} onSolve={onSolve} onWrong={onWrong} />}
                  {stop.id === 'lamp' && <LampStop caps={caps} solved={false} onSolve={onSolve} onWrong={onWrong} />}
                </div>
              </>
            )}
          </section>

          {caps && !finished && (
            <Tutor caps={caps} hint={hint} thinking={thinking} onAsk={(q) => void askTutor(lastWrong.current, q)} />
          )}
        </main>

        <aside className="space-y-4">
          <Bedroom watts={progress.watts} />
          <AgeSwitcher band={band} region={region} caps={caps} loading={capsLoading} onChange={(b, r) => { setBand(b); setRegion(r); }} />

          <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-3">
            <div className="text-xs font-semibold text-slate-300 mb-2">Component cards</div>
            <div className="flex gap-2">
              {STOPS.map((s) => progress.cards.includes(s.id)
                ? <Card key={s.id} id={s.id} />
                : <div key={s.id} className="w-20 h-24 rounded-lg border border-dashed border-slate-700 flex items-center justify-center text-slate-600 text-xs">?</div>)}
            </div>
          </div>

          {caps && caps.sharing !== 'none' && (
            <button onClick={share} className="w-full rounded-2xl border border-fuchsia-900/60 bg-fuchsia-950/30 p-3 text-sm text-left hover:border-fuchsia-600">
              <div className="font-semibold text-fuchsia-300">{caps.sharing === 'open' ? '🔗 Share your lamp' : '👪 Share with family'}</div>
              <div className="text-xs text-slate-400">{caps.sharing === 'open' ? 'Copy a link to your progress and custom levels.' : 'A parent approves before anything leaves this device.'}</div>
            </button>
          )}
          {caps && caps.sharing === 'none' && (
            <div className="rounded-2xl border border-slate-800 p-3 text-xs text-slate-500">Sharing is off for this player. Nothing leaves the device.</div>
          )}

          {caps && caps.dataPolicy !== 'minimal' && (
            <details className="rounded-2xl border border-slate-800 p-3 text-xs text-slate-400">
              <summary className="cursor-pointer text-slate-300">What the tutor remembers</summary>
              <pre className="mt-2 whitespace-pre-wrap font-mono text-[11px]">{JSON.stringify(progress.memory, null, 2)}</pre>
            </details>
          )}
        </aside>
      </div>

      {toast && <div className="fixed bottom-5 left-1/2 -translate-x-1/2 rounded-full bg-slate-100 text-slate-900 px-4 py-2 text-sm shadow-lg pop">{toast}</div>}
    </div>
  );
}

function Card({ id }: { id: StopId }) {
  const c = CARDS[id];
  return (
    <div title={c.fact} className="w-20 h-24 rounded-lg border border-amber-500/60 bg-gradient-to-b from-amber-900/40 to-slate-900 p-1.5 text-center pop">
      <div className="text-2xl">{c.emoji}</div>
      <div className="text-[10px] font-semibold leading-tight mt-1">{c.title}</div>
    </div>
  );
}
