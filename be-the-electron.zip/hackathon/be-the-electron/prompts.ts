import type { Capabilities, HintRequest, LearnerMemory } from './types';

const STOP_FACTS: Record<string, string> = {
  wire: 'Copper, silver and aluminum are conductors: electrons move through them easily. Rubber, wood and plastic are insulators: they block electrons. In a series path, resistances add up.',
  switch: 'Electrons only flow when the loop is closed all the way around. One open switch anywhere in a series path stops everything. In a parallel branch, one closed path is enough.',
  lamp: 'Resistance turns electron flow into heat and light. Too little resistance means too much current and the filament burns out. Too much resistance means a dim lamp. Ohm\'s law: V = I × R, so with 12 V and a target of 0.5 A you need 24 Ω.',
};

const PERSONA: Record<Capabilities['tutorMode'], string> = {
  voice: `You are a warm voice helper for a 6-year-old who is playing as an electron.
Reply in ONE or TWO very short sentences using words a kindergartner knows.
No numbers, no technical terms. End with one tiny thing to try next.
Never ask the child to type or read anything long. Your words will be spoken aloud.`,
  guided: `You are a friendly science coach for a 10-year-old who is playing as an electron.
Reply in 2–3 sentences. Use one concrete analogy (water in pipes, a crowded hallway, a slide).
Ask one guiding question instead of giving the answer away.
Also offer exactly 3 short follow-up questions a curious kid might tap on.`,
  open: `You are a sharp, encouraging physics tutor for a 15-year-old who is playing as an electron.
Use correct vocabulary (conductor, insulator, resistance, current, Ohm's law V = IR).
Reply in 2–4 sentences; one short calculation is welcome. Push them to reason, don't just hand over the answer.
Offer up to 3 follow-up questions that go one level deeper.`,
};

export function buildSystemPrompt(caps: Capabilities, memory: LearnerMemory): string {
  const memoryLine =
    caps.dataPolicy === 'minimal'
      ? 'You know nothing about this learner beyond this one mistake.'
      : `Learner so far: hints used ${memory.hintsUsed}; stops completed: ${memory.stopsCompleted.join(', ') || 'none'}; misconceptions seen: ${memory.misconceptionsSeen.join(', ') || 'none'}. If one of those is relevant, connect to it in a few words ("remember how rubber blocked you?").`;
  return `${PERSONA[caps.tutorMode]}

The game: the player is a single electron travelling from a power plant to a bedroom reading lamp. Each solved stop delivers watts that make the lamp brighter.
${memoryLine}
Never mention age, grade, or that you were told a reading level. Never ask for personal information.`;
}

export function buildUserPrompt(req: HintRequest): string {
  const base = `Stop: ${req.stop} (concept: ${req.concept}).
Science facts you may rely on: ${STOP_FACTS[req.stop]}
The player's attempt #${req.attempt}: ${req.wrongChoice}.`;
  return req.question ? `${base}\nThe player now asks: "${req.question}"` : `${base}\nExplain what went wrong and nudge them toward the idea.`;
}

export const HINT_SCHEMA_DESCRIPTION = {
  hint: 'The spoken or shown explanation, at the reading level described.',
  misconception: 'A 2–5 word label for the mistake, e.g. "insulator treated as conductor".',
  followUps: 'Short follow-up questions the learner could ask next. Empty array for the voice persona.',
};
