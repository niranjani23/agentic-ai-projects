import { useEffect, useRef, useState } from 'react';
import { MATERIALS, material, type MaterialId, type StopProps } from './stops';

const SEGMENT_LENGTHS = [1, 2, 1]; // teens: resistance scales with length
const TARGET_OHMS = 5;
const VOLTS = 12;

export default function WireStop({ caps, solved, onSolve, onWrong }: StopProps) {
  const gaps = caps.inputMode === 'tap' ? 1 : 3;
  const [choice, setChoice] = useState<(MaterialId | null)[]>(Array(gaps).fill(null));
  const [phase, setPhase] = useState<'idle' | 'running' | 'blocked' | 'done'>(solved ? 'done' : 'idle');
  const [pos, setPos] = useState(solved ? 100 : 2);
  const [speedMs, setSpeedMs] = useState(1200);
  const timer = useRef<number | null>(null);
  useEffect(() => () => { if (timer.current) window.clearTimeout(timer.current); }, []);

  const options = caps.inputMode === 'tap' ? MATERIALS.filter((m) => ['copper', 'rubber', 'wood'].includes(m.id)) : MATERIALS;
  const gapPositions = gaps === 1 ? [50] : [25, 50, 75];
  const totalOhms = choice.reduce<number>((sum, id, i) => (id ? sum + material(id).ohms * (caps.inputMode === 'calculate' ? SEGMENT_LENGTHS[i] : 1) : sum), 0);

  function send(selection: (MaterialId | null)[]) {
    if (selection.some((c) => !c) || phase === 'running' || phase === 'done') return;
    const mats = selection.map((id) => material(id!));
    const firstInsulator = mats.findIndex((m) => !m.conductor);
    const overTarget = caps.inputMode === 'calculate' && firstInsulator === -1 && totalOhms > TARGET_OHMS;
    setPhase('running');
    if (firstInsulator >= 0) {
      setSpeedMs(900);
      setPos(gapPositions[firstInsulator] - 4);
      timer.current = window.setTimeout(() => {
        setPhase('blocked');
        onWrong(`put ${mats[firstInsulator].name.toLowerCase()} in the wire; the electron stopped there`, 'insulator treated as conductor');
      }, 950);
    } else if (overTarget) {
      setSpeedMs(2600);
      setPos(100);
      timer.current = window.setTimeout(() => {
        setPhase('blocked');
        onWrong(`chose ${mats.map((m) => m.name).join(', ')} for a total of ${totalOhms} Ω in series, above the ${TARGET_OHMS} Ω target, so the current was too weak`, 'ignored series resistance adding up');
      }, 2650);
    } else {
      const ms = 700 + totalOhms * 180;
      setSpeedMs(ms);
      setPos(100);
      timer.current = window.setTimeout(() => { setPhase('done'); onSolve(); }, ms + 50);
    }
  }

  function pick(i: number, id: MaterialId) {
    const next = [...choice];
    next[i] = id;
    setChoice(next);
    setPhase('idle');
    setPos(2);
    if (caps.inputMode === 'tap') send(next);
  }

  return (
    <div>
      <Instruction caps={caps} />

      {/* the wire */}
      <div className="relative h-24 my-4">
        <div className="absolute left-0 right-0 top-1/2 h-2 -translate-y-1/2 bg-amber-700/70 rounded" />
        {gapPositions.map((p, i) => {
          const m = choice[i] ? material(choice[i]!) : null;
          return (
            <div key={i} className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2" style={{ left: `${p}%` }}>
              <div className={`w-14 h-14 rounded-xl border-2 flex items-center justify-center text-2xl ${m ? (m.conductor ? 'border-amber-400 bg-amber-900/40' : 'border-slate-500 bg-slate-800') : 'border-dashed border-slate-500 bg-slate-900'}`}>
                {m ? m.emoji : '?'}
              </div>
              {caps.inputMode === 'calculate' && <div className="text-center text-[10px] text-slate-400 mt-1">len {SEGMENT_LENGTHS[i]}</div>}
            </div>
          );
        })}
        <div
          className={`absolute top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-sky-300 shadow-[0_0_18px_6px_rgba(125,211,252,.7)] flex items-center justify-center text-xs font-bold text-slate-900 ${phase === 'blocked' ? 'shake' : ''}`}
          style={{ left: `calc(${pos}% - 12px)`, transition: `left ${speedMs}ms ${phase === 'running' ? 'ease-in' : 'ease-out'}` }}
        >
          e⁻
        </div>
      </div>

      {/* choices */}
      {Array.from({ length: gaps }).map((_, i) => (
        <div key={i} className="mb-2">
          {gaps > 1 && <div className="text-xs text-slate-400 mb-1">Gap {i + 1}</div>}
          <div className={`grid gap-2 ${caps.inputMode === 'tap' ? 'grid-cols-3' : 'grid-cols-6'}`}>
            {options.map((m) => (
              <button
                key={m.id}
                disabled={phase === 'done'}
                onClick={() => pick(i, m.id)}
                className={`rounded-xl border px-2 ${caps.inputMode === 'tap' ? 'py-4 text-lg' : 'py-2 text-xs'} transition ${choice[i] === m.id ? 'border-sky-400 bg-sky-900/40' : 'border-slate-700 bg-slate-900 hover:border-slate-500'}`}
              >
                <div className={caps.inputMode === 'tap' ? 'text-4xl' : 'text-2xl'}>{m.emoji}</div>
                <div>{m.name}</div>
                {caps.inputMode === 'calculate' && <div className="font-mono text-[10px] text-slate-400">{m.conductor ? `${m.ohms} Ω/len` : '∞ Ω'}</div>}
              </button>
            ))}
          </div>
        </div>
      ))}

      {caps.inputMode === 'calculate' && (
        <div className="mt-2 rounded-lg bg-slate-900 border border-slate-800 p-2 font-mono text-xs text-slate-300">
          R_total = {choice.map((id, i) => (id ? `${material(id).ohms}×${SEGMENT_LENGTHS[i]}` : '?')).join(' + ')} = {Number.isFinite(totalOhms) ? totalOhms : '∞'} Ω (target ≤ {TARGET_OHMS} Ω)
          <br />I = V / R = {VOLTS} V / {Number.isFinite(totalOhms) && totalOhms > 0 ? `${totalOhms} Ω = ${(VOLTS / totalOhms).toFixed(2)} A` : '…'}
        </div>
      )}

      {caps.inputMode !== 'tap' && phase !== 'done' && (
        <button
          onClick={() => send(choice)}
          disabled={choice.some((c) => !c) || phase === 'running'}
          className="mt-3 w-full rounded-xl bg-sky-500 py-3 font-semibold text-slate-950 disabled:opacity-40"
        >
          {phase === 'running' ? 'Zooming…' : phase === 'blocked' ? 'Try again' : 'Send the electron ⚡'}
        </button>
      )}
      {phase === 'done' && <div className="mt-3 text-center text-emerald-300 font-semibold pop">The electron made it through! +40 W</div>}
    </div>
  );
}

function Instruction({ caps }: { caps: StopProps['caps'] }) {
  const text = {
    tap: 'The wire has a hole! Tap the thing that lets the electron zoom through.',
    build: 'Fill all three gaps. Only some materials let electrons through. Then send the electron.',
    calculate: `Fill the gaps so the electron arrives with enough current. Resistances add in series; keep the total at or under ${TARGET_OHMS} Ω.`,
  }[caps.inputMode];
  return <p className={caps.inputMode === 'tap' ? 'text-xl leading-snug' : 'text-sm text-slate-300'}>{text}</p>;
}
