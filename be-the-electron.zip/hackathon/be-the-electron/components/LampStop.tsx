import { useState } from 'react';
import Bulb from './Bulb';
import type { StopProps } from './stops';

const VOLTS = 12;
const TARGET_AMPS = 0.5;
const BURNOUT_AMPS = 1.0;

/** brightness from current: full at the target, burnt above the burnout limit */
function brightnessFor(amps: number) {
  if (amps >= BURNOUT_AMPS) return { b: 0, burnt: true };
  return { b: Math.min(1, amps / TARGET_AMPS), burnt: false };
}

export default function LampStop({ caps, solved, onSolve, onWrong }: StopProps) {
  const [done, setDone] = useState(solved);
  const [ohms, setOhms] = useState(60);
  const [entry, setEntry] = useState('');
  const [picked, setPicked] = useState('');
  const amps = ohms > 0 ? VOLTS / ohms : BURNOUT_AMPS;
  const { b, burnt } = brightnessFor(amps);

  function finish() { setDone(true); onSolve(); }

  if (caps.inputMode === 'tap') {
    const choices = [
      { label: 'Tiny bit', emoji: '🐜', amps: 1.2, wrong: 'chose almost no resistance, so too many electrons rushed through and the lamp popped', misconception: 'less resistance always better' },
      { label: 'Just right', emoji: '👌', amps: 0.5 },
      { label: 'Huge', emoji: '🐘', amps: 0.08, wrong: 'chose a huge resistance, so hardly any electrons got through and the lamp stayed dim', misconception: 'more resistance means brighter' },
    ];
    const pickedChoice = choices.find((c) => c.label === picked);
    const view = pickedChoice ? brightnessFor(pickedChoice.amps) : { b: 0.1, burnt: false };
    return (
      <div>
        <p className="text-xl leading-snug">The lamp needs just the right squeeze. How much should it slow the electrons down?</p>
        <div className="flex justify-center my-4"><Bulb brightness={view.b} burnt={view.burnt} size={90} /></div>
        <div className="grid grid-cols-3 gap-3">
          {choices.map((c) => (
            <button key={c.label} disabled={done} onClick={() => { setPicked(c.label); if (c.wrong) onWrong(c.wrong, c.misconception!); else finish(); }}
              className={`rounded-2xl border-2 p-4 text-lg ${picked === c.label ? (c.wrong ? 'border-rose-500' : 'border-emerald-400') : 'border-slate-700 bg-slate-900 hover:border-sky-500'}`}>
              <div className="text-4xl">{c.emoji}</div>{c.label}
            </button>
          ))}
        </div>
        {done && <div className="mt-3 text-center text-emerald-300 font-semibold pop">Perfect glow! +40 W</div>}
      </div>
    );
  }

  if (caps.inputMode === 'build') {
    const inZone = ohms >= 20 && ohms <= 30; // 0.4–0.6 A
    return (
      <div>
        <p className="text-sm text-slate-300">Slide the resistance until the lamp glows bright without burning out, then light it.</p>
        <div className="flex justify-center my-4"><Bulb brightness={b} burnt={burnt} size={90} /></div>
        <input type="range" min={5} max={100} value={ohms} onChange={(e) => setOhms(Number(e.target.value))} disabled={done} className="w-full accent-amber-400" />
        <div className="flex justify-between text-xs text-slate-400 font-mono"><span>5 Ω (floods)</span><span>{ohms} Ω</span><span>100 Ω (trickle)</span></div>
        {!done ? (
          <button onClick={() => {
            if (inZone) finish();
            else if (ohms < 20) onWrong(`set resistance to ${ohms} Ω, which is too low; the current is ${amps.toFixed(2)} A and the filament ${burnt ? 'burned out' : 'is close to burning out'}`, 'less resistance always better');
            else onWrong(`set resistance to ${ohms} Ω, which is too high; only ${amps.toFixed(2)} A gets through and the lamp is dim`, 'more resistance means brighter');
          }} className="mt-3 w-full rounded-xl bg-sky-500 py-3 font-semibold text-slate-950">Light it 💡</button>
        ) : <div className="mt-3 text-center text-emerald-300 font-semibold pop">Balanced! The room lights up. +40 W</div>}
      </div>
    );
  }

  // calculate: Ohm's law
  const parsed = Number(entry);
  const preview = entry && parsed > 0 ? brightnessFor(VOLTS / parsed) : { b: 0.1, burnt: false };
  return (
    <div>
      <p className="text-sm text-slate-300">The lamp runs on {VOLTS} V and glows perfectly at {TARGET_AMPS} A. Above {BURNOUT_AMPS} A the filament burns out. What resistance should the filament have?</p>
      <div className="flex justify-center my-4"><Bulb brightness={preview.b} burnt={preview.burnt} size={90} /></div>
      <div className="rounded-lg bg-slate-900 border border-slate-800 p-2 font-mono text-xs text-slate-300 mb-3">V = I × R → R = V / I</div>
      <form className="flex gap-2" onSubmit={(e) => {
        e.preventDefault();
        if (done || !(parsed > 0)) return;
        const i = VOLTS / parsed;
        if (Math.abs(parsed - VOLTS / TARGET_AMPS) <= 0.5) finish();
        else if (i >= BURNOUT_AMPS) onWrong(`entered ${parsed} Ω, giving I = ${i.toFixed(2)} A, above the ${BURNOUT_AMPS} A burnout limit`, 'solved V=IR for the wrong quantity');
        else if (parsed < VOLTS / TARGET_AMPS) onWrong(`entered ${parsed} Ω, giving I = ${i.toFixed(2)} A, more than the ${TARGET_AMPS} A target`, 'resistance too low for target current');
        else onWrong(`entered ${parsed} Ω, giving I = ${i.toFixed(2)} A, less than the ${TARGET_AMPS} A target so the lamp is dim`, 'resistance too high for target current');
      }}>
        <input value={entry} onChange={(e) => setEntry(e.target.value)} disabled={done} inputMode="decimal" placeholder="R in ohms" className="flex-1 rounded-md bg-slate-900 border border-slate-700 px-3 py-2 font-mono outline-none focus:border-sky-500" />
        <button disabled={done} className="rounded-md bg-sky-500 px-4 font-semibold text-slate-950 disabled:opacity-40">Set R</button>
      </form>
      {done && <div className="mt-3 text-center text-emerald-300 font-semibold pop">R = {VOLTS / TARGET_AMPS} Ω. Exactly {TARGET_AMPS} A. +40 W</div>}
    </div>
  );
}
