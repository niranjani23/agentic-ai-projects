import { MAX_WATTS } from '../types';

/** The reward view: delivered watts light up a kid's bedroom lamp. */
export default function Bedroom({ watts }: { watts: number }) {
  const level = Math.min(1, watts / MAX_WATTS);
  const glow = 0.12 + level * 0.88;
  const roomBg = `rgb(${8 + level * 50}, ${10 + level * 42}, ${30 + level * 28})`;
  return (
    <div className="rounded-2xl overflow-hidden border border-slate-800" style={{ background: roomBg, transition: 'background 800ms' }}>
      <div className="relative h-56">
        {/* window */}
        <div className="absolute left-5 top-5 w-16 h-20 rounded-md border-2 border-slate-600/60 bg-slate-900/60 grid grid-cols-2 grid-rows-2 gap-0.5 p-0.5">
          {[0, 1, 2, 3].map((i) => <div key={i} className="bg-indigo-950/80 rounded-sm" />)}
        </div>
        {/* bed */}
        <div className="absolute left-4 bottom-4 w-40 h-14 rounded-md" style={{ background: `rgba(160,110,200,${0.25 + level * 0.6})` }} />
        <div className="absolute left-6 bottom-14 w-14 h-7 rounded-md" style={{ background: `rgba(230,230,240,${0.3 + level * 0.6})` }} />
        {/* desk */}
        <div className="absolute right-6 bottom-6 w-28 h-3 rounded" style={{ background: `rgba(140,100,60,${0.4 + level * 0.5})` }} />
        <div className="absolute right-8 bottom-0 w-2 h-6 bg-amber-900/70" />
        <div className="absolute right-28 bottom-0 w-2 h-6 bg-amber-900/70" />
        {/* lamp */}
        <div className="absolute right-10 bottom-9 flex flex-col items-center">
          <div
            className="w-20 h-12 rounded-t-full"
            style={{
              background: `rgba(255, 214, 120, ${glow})`,
              boxShadow: `0 0 ${20 + level * 90}px ${8 + level * 40}px rgba(255, 200, 90, ${level * 0.55})`,
              transition: 'all 800ms',
            }}
          />
          <div className="w-1.5 h-10 bg-slate-500" />
          <div className="w-10 h-1.5 rounded-full bg-slate-500" />
        </div>
        {/* glow on the book */}
        <div className="absolute right-14 bottom-9 w-8 h-5 rounded-sm" style={{ background: `rgba(255,255,255,${0.15 + level * 0.7})`, transition: 'all 800ms' }} />
      </div>
      <div className="px-4 py-2 flex items-center justify-between text-xs text-slate-300 bg-slate-950/50">
        <span>Bedroom lamp</span>
        <span className="font-mono">{watts} / {MAX_WATTS} W delivered</span>
      </div>
      <div className="h-1.5 bg-slate-800">
        <div className="h-full bg-amber-400 transition-all duration-700" style={{ width: `${level * 100}%` }} />
      </div>
    </div>
  );
}
