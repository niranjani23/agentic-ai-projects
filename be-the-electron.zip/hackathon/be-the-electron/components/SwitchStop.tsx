import { useState } from 'react';
import Bulb from './Bulb';
import type { StopProps } from './stops';

/**
 * tap: one switch, pick the picture that lets the electron through
 * build: two switches in series, both must be closed
 * calculate: S1 in series with a parallel pair (S2 ∥ S3); light the lamp with the fewest closed switches
 */
export default function SwitchStop({ caps, solved, onSolve, onWrong }: StopProps) {
  const n = caps.inputMode === 'tap' ? 1 : caps.inputMode === 'build' ? 2 : 3;
  const [closed, setClosed] = useState<boolean[]>(Array(n).fill(false));
  const [done, setDone] = useState(solved);
  const [lit, setLit] = useState(solved);

  const isLit = (c: boolean[]) => (caps.inputMode === 'calculate' ? c[0] && (c[1] || c[2]) : c.every(Boolean));

  function test(c: boolean[]) {
    const litNow = isLit(c);
    setLit(litNow);
    if (!litNow) {
      const open = c.map((v, i) => (!v ? `S${i + 1}` : null)).filter(Boolean).join(', ');
      onWrong(`sent the electron with ${open || 'nothing'} still open, so the loop was not closed`, 'open loop expected to conduct');
      return;
    }
    if (caps.inputMode === 'calculate' && c.filter(Boolean).length > 2) {
      onWrong('closed all three switches; the lamp lit but that is not the fewest switches needed', 'parallel branch needs only one path');
      return;
    }
    setDone(true);
    onSolve();
  }

  function toggle(i: number) {
    if (done) return;
    const c = [...closed];
    c[i] = !c[i];
    setClosed(c);
    setLit(false);
  }

  if (caps.inputMode === 'tap') {
    return (
      <div>
        <p className="text-xl leading-snug">The lamp keeps blinking! Which switch lets the electron go all the way around?</p>
        <div className="flex justify-center my-4"><Bulb brightness={done ? 1 : 0.4} flicker={!done} size={80} /></div>
        <div className="grid grid-cols-2 gap-3">
          <button disabled={done} onClick={() => onWrong('tapped the open switch, leaving a gap in the loop', 'open loop expected to conduct')} className="rounded-2xl border-2 border-slate-700 bg-slate-900 p-4 hover:border-sky-500">
            <SwitchIcon closed={false} big />
            <div className="mt-2 text-lg">Open</div>
          </button>
          <button disabled={done} onClick={() => { setClosed([true]); test([true]); }} className={`rounded-2xl border-2 p-4 ${done ? 'border-emerald-400 bg-emerald-900/30' : 'border-slate-700 bg-slate-900 hover:border-sky-500'}`}>
            <SwitchIcon closed big />
            <div className="mt-2 text-lg">Closed</div>
          </button>
        </div>
        {done && <div className="mt-3 text-center text-emerald-300 font-semibold pop">The loop is closed. The lamp stays on! +40 W</div>}
      </div>
    );
  }

  return (
    <div>
      <p className="text-sm text-slate-300">
        {caps.inputMode === 'build'
          ? 'Two switches sit on the same loop. Set them so the electron can travel all the way around, then send it.'
          : 'S1 is in series with a parallel pair, S2 and S3. Light the lamp using the fewest closed switches.'}
      </p>
      <div className="my-4 rounded-xl border border-slate-800 bg-slate-900/60 p-4">
        <div className="flex items-center justify-around">
          <div className="text-center text-xs text-slate-400">🔋<div>12 V</div></div>
          {caps.inputMode === 'build' ? (
            <>
              <SwitchButton i={0} closed={closed[0]} onClick={toggle} />
              <Wire />
              <SwitchButton i={1} closed={closed[1]} onClick={toggle} />
            </>
          ) : (
            <>
              <SwitchButton i={0} closed={closed[0]} onClick={toggle} />
              <Wire />
              <div className="flex flex-col gap-2 border-l-2 border-r-2 border-slate-600 px-3 py-1">
                <SwitchButton i={1} closed={closed[1]} onClick={toggle} />
                <SwitchButton i={2} closed={closed[2]} onClick={toggle} />
              </div>
            </>
          )}
          <Wire />
          <Bulb brightness={lit ? 1 : 0.35} flicker={!lit && !done} size={56} />
        </div>
        {caps.inputMode === 'calculate' && (
          <div className="mt-3 font-mono text-xs text-slate-400">lamp = S1 AND (S2 OR S3) · closed now: {closed.filter(Boolean).length}</div>
        )}
      </div>
      {!done ? (
        <button onClick={() => test(closed)} className="w-full rounded-xl bg-sky-500 py-3 font-semibold text-slate-950">Send the electron ⚡</button>
      ) : (
        <div className="text-center text-emerald-300 font-semibold pop">Closed loop! The lamp stays on. +40 W</div>
      )}
    </div>
  );
}

function Wire() { return <div className="h-1 w-8 bg-amber-700/70" />; }

function SwitchButton({ i, closed, onClick }: { i: number; closed: boolean; onClick: (i: number) => void }) {
  return (
    <button onClick={() => onClick(i)} className={`rounded-lg border px-2 py-1 ${closed ? 'border-emerald-500 bg-emerald-900/30' : 'border-slate-600 bg-slate-800'}`}>
      <SwitchIcon closed={closed} />
      <div className="text-[10px] text-slate-300">S{i + 1} · {closed ? 'closed' : 'open'}</div>
    </button>
  );
}

function SwitchIcon({ closed, big = false }: { closed: boolean; big?: boolean }) {
  const w = big ? 120 : 56, h = big ? 50 : 24;
  return (
    <svg width={w} height={h} viewBox="0 0 120 50" className="mx-auto">
      <line x1="0" y1="35" x2="35" y2="35" stroke="#b45309" strokeWidth="6" />
      <line x1="85" y1="35" x2="120" y2="35" stroke="#b45309" strokeWidth="6" />
      <circle cx="35" cy="35" r="6" fill="#e2e8f0" />
      <circle cx="85" cy="35" r="6" fill="#e2e8f0" />
      <line x1="35" y1="35" x2={closed ? 85 : 75} y2={closed ? 35 : 5} stroke={closed ? '#34d399' : '#e2e8f0'} strokeWidth="6" strokeLinecap="round" />
    </svg>
  );
}
