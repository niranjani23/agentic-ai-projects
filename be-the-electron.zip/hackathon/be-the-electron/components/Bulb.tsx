/** Small bulb used inside the stops. brightness 0..1; burnt shows a popped filament. */
export default function Bulb({ brightness, burnt = false, flicker = false, size = 64 }: { brightness: number; burnt?: boolean; flicker?: boolean; size?: number }) {
  const b = burnt ? 0 : Math.max(0, Math.min(1, brightness));
  return (
    <div className="flex flex-col items-center" style={{ width: size }}>
      <div
        className={`rounded-full border-2 ${flicker ? 'flicker' : ''}`}
        style={{
          width: size,
          height: size,
          borderColor: burnt ? '#7f1d1d' : 'rgba(253,230,138,0.6)',
          background: burnt ? 'radial-gradient(circle, #1f2937, #0f172a)' : `radial-gradient(circle, rgba(255,240,180,${0.15 + b * 0.85}), rgba(255,200,80,${b * 0.6}) 60%, transparent)`,
          boxShadow: burnt ? 'none' : `0 0 ${b * 40}px ${b * 14}px rgba(255,200,90,${b * 0.6})`,
          transition: 'all 400ms',
        }}
      >
        {burnt && <div className="w-full h-full flex items-center justify-center text-2xl">💥</div>}
      </div>
      <div className="w-5 h-3 bg-slate-500 rounded-b-sm" />
    </div>
  );
}
