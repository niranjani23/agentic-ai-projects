import type { AgeBand, Capabilities, Region } from '../types';

const BANDS: { band: AgeBand; label: string; emoji: string }[] = [
  { band: '5-7', label: 'Age 6', emoji: '🧒' },
  { band: '8-12', label: 'Age 10', emoji: '👧' },
  { band: '13-17', label: 'Age 15', emoji: '🧑' },
];
const REGIONS: Region[] = ['US', 'DE', 'UK', 'BR'];

interface Props {
  band: AgeBand;
  region: Region;
  caps: Capabilities | null;
  loading: boolean;
  onChange: (band: AgeBand, region: Region) => void;
}

/** Demo-only control standing in for k-ID's age assurance. Hidden from real players. */
export default function AgeSwitcher({ band, region, caps, loading, onChange }: Props) {
  return (
    <div className="rounded-2xl border border-emerald-900/60 bg-emerald-950/30 p-3 text-sm">
      <div className="flex items-center justify-between mb-2">
        <span className="font-semibold text-emerald-300">Demo: play as…</span>
        <span className="text-[10px] uppercase tracking-wide text-emerald-500">k-ID mock</span>
      </div>
      <div className="flex gap-2 mb-2">
        {BANDS.map((b) => (
          <button
            key={b.band}
            onClick={() => onChange(b.band, region)}
            className={`flex-1 rounded-xl px-2 py-2 border transition ${band === b.band ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-semibold' : 'bg-slate-900 border-slate-700 hover:border-emerald-600'}`}
          >
            <div className="text-xl">{b.emoji}</div>
            <div className="text-xs">{b.label}</div>
          </button>
        ))}
      </div>
      <div className="flex items-center gap-2 mb-2">
        <span className="text-xs text-slate-400">Region</span>
        {REGIONS.map((r) => (
          <button
            key={r}
            onClick={() => onChange(band, r)}
            className={`rounded-md px-2 py-0.5 text-xs border ${region === r ? 'bg-emerald-700/60 border-emerald-500' : 'border-slate-700 hover:border-emerald-600'}`}
          >
            {r}
          </button>
        ))}
      </div>
      {loading || !caps ? (
        <div className="text-xs text-slate-400 animate-pulse">Asking k-ID what this player may do…</div>
      ) : (
        <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
          <Cap label="Input" value={caps.inputMode} />
          <Cap label="AI tutor" value={caps.tutorMode} />
          <Cap label="Sharing" value={caps.sharing} />
          <Cap label="Data" value={caps.dataPolicy} />
          <div className="col-span-2 text-slate-400 mt-1">{caps.rationale}</div>
        </div>
      )}
    </div>
  );
}

function Cap({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between border-b border-slate-800/80 pb-0.5">
      <span className="text-slate-400">{label}</span>
      <span className="font-mono text-emerald-200">{value}</span>
    </div>
  );
}
