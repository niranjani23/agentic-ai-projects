import { useState } from 'react';
import type { Capabilities, Hint } from '../types';
import { geminiAvailable, speak } from '../gemini';

interface Props {
  caps: Capabilities;
  hint: Hint | null;
  thinking: boolean;
  onAsk: (question: string) => void;
}

/** One tutor, three faces: voice-only, guided buttons, or open chat. Decided by capabilities. */
export default function Tutor({ caps, hint, thinking, onAsk }: Props) {
  const [draft, setDraft] = useState('');
  const title = { voice: 'Spark says', guided: 'Coach Spark', open: 'Tutor' }[caps.tutorMode];

  return (
    <div className="rounded-2xl border border-sky-900/60 bg-sky-950/30 p-3 text-sm min-h-[8rem]">
      <div className="flex items-center justify-between mb-2">
        <span className="font-semibold text-sky-300">⚡ {title}</span>
        <span className="text-[10px] uppercase tracking-wide text-sky-500">
          {geminiAvailable() ? 'Gemini 2.5 Flash' : 'offline hints (no API key)'} · {caps.tutorMode}
        </span>
      </div>

      {thinking && <div className="text-sky-200/80 animate-pulse">thinking…</div>}

      {!thinking && !hint && (
        <div className="text-slate-400">
          {caps.tutorMode === 'voice' && 'I will talk to you if the electron gets stuck.'}
          {caps.tutorMode === 'guided' && 'Make a wrong move and I will give you a clue and some questions to tap.'}
          {caps.tutorMode === 'open' && 'Get stuck and I will explain. You can also ask me anything about the circuit.'}
        </div>
      )}

      {!thinking && hint && (
        <div className="pop">
          <p className={caps.tutorMode === 'voice' ? 'text-lg leading-snug' : 'leading-relaxed'}>{hint.hint}</p>
          {caps.tutorMode === 'voice' && (
            <button onClick={() => speak(hint.hint)} className="mt-2 rounded-full bg-sky-600 px-4 py-2 text-base">🔊 Say it again</button>
          )}
          {caps.tutorMode !== 'voice' && hint.misconception && (
            <div className="mt-1 text-[11px] text-slate-400">noted: <span className="font-mono">{hint.misconception}</span> · {hint.source}</div>
          )}
          {caps.tutorMode === 'guided' && hint.followUps.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-2">
              {hint.followUps.map((q) => (
                <button key={q} onClick={() => onAsk(q)} className="rounded-full border border-sky-700 bg-sky-900/40 px-3 py-1 text-xs hover:bg-sky-800/60">{q}</button>
              ))}
            </div>
          )}
          {caps.tutorMode === 'open' && hint.followUps.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-2">
              {hint.followUps.map((q) => (
                <button key={q} onClick={() => onAsk(q)} className="rounded-md border border-slate-700 px-2 py-1 text-xs hover:border-sky-500">{q}</button>
              ))}
            </div>
          )}
        </div>
      )}

      {caps.tutorMode === 'open' && (
        <form
          className="mt-3 flex gap-2"
          onSubmit={(e) => { e.preventDefault(); if (draft.trim()) { onAsk(draft.trim()); setDraft(''); } }}
        >
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Ask anything about this circuit…"
            className="flex-1 rounded-md bg-slate-900 border border-slate-700 px-3 py-1.5 text-sm outline-none focus:border-sky-500"
          />
          <button className="rounded-md bg-sky-600 px-3 py-1.5 text-sm">Ask</button>
        </form>
      )}
    </div>
  );
}
