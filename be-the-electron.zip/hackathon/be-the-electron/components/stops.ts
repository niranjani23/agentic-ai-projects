import type { Capabilities } from '../types';

export interface StopProps {
  caps: Capabilities;
  solved: boolean;
  onSolve: () => void;
  /** wrongChoice is a plain-language description sent to the tutor; misconception is a short label for learner memory. */
  onWrong: (wrongChoice: string, misconception: string) => void;
}

export const MATERIALS = [
  { id: 'copper', name: 'Copper', emoji: '🟠', ohms: 1, conductor: true },
  { id: 'silver', name: 'Silver', emoji: '⚪', ohms: 0.5, conductor: true },
  { id: 'aluminum', name: 'Aluminum', emoji: '🩶', ohms: 2, conductor: true },
  { id: 'rubber', name: 'Rubber', emoji: '⚫', ohms: Infinity, conductor: false },
  { id: 'wood', name: 'Wood', emoji: '🪵', ohms: Infinity, conductor: false },
  { id: 'plastic', name: 'Plastic', emoji: '🟦', ohms: Infinity, conductor: false },
] as const;
export type MaterialId = (typeof MATERIALS)[number]['id'];
export const material = (id: MaterialId) => MATERIALS.find((m) => m.id === id)!;
