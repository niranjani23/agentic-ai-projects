export type AgeBand = '5-7' | '8-12' | '13-17';
export type Region = 'US' | 'DE' | 'UK' | 'BR';
export type StopId = 'wire' | 'switch' | 'lamp';

/** What the app is allowed to do for this user. Produced by the k-ID adapter, never by the UI. */
export interface Capabilities {
  ageBand: AgeBand;
  region: Region;
  inputMode: 'tap' | 'build' | 'calculate';
  tutorMode: 'voice' | 'guided' | 'open';
  sharing: 'none' | 'parent-approved' | 'open';
  dataPolicy: 'minimal' | 'consented' | 'regional';
  /** Human-readable reason for the policy, shown in the demo overlay. */
  rationale: string;
}

/** Small, inspectable learner profile the tutor is allowed to remember. */
export interface LearnerMemory {
  misconceptionsSeen: string[];
  hintsUsed: number;
  stopsCompleted: StopId[];
}

export interface HintRequest {
  stop: StopId;
  concept: string;
  wrongChoice: string;
  attempt: number;
  /** Only present in open-chat mode (teens). */
  question?: string;
}

export interface Hint {
  hint: string;
  misconception: string;
  followUps: string[];
  source: 'gemini' | 'offline';
}

export interface ComponentCard {
  id: StopId;
  title: string;
  emoji: string;
  fact: string;
}

export const STOPS: { id: StopId; title: string; concept: string; watts: number }[] = [
  { id: 'wire', title: 'The Wire', concept: 'conductors vs. insulators', watts: 40 },
  { id: 'switch', title: 'The Switch', concept: 'open vs. closed circuits', watts: 40 },
  { id: 'lamp', title: 'The Lamp', concept: 'resistance and energy', watts: 40 },
];

export const MAX_WATTS = STOPS.reduce((n, s) => n + s.watts, 0);

export const CARDS: Record<StopId, ComponentCard> = {
  wire: { id: 'wire', title: 'Copper Wire', emoji: '🧡', fact: 'Copper lets electrons slide through easily. Rubber blocks them.' },
  switch: { id: 'switch', title: 'Switch', emoji: '🔘', fact: 'Electrons only flow around a closed loop. Open the loop and they stop.' },
  lamp: { id: 'lamp', title: 'Filament', emoji: '💡', fact: 'Resistance turns moving electrons into heat and light. Too much and the lamp goes dim.' },
};
