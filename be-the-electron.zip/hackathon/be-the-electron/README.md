# ⚡ Be the Electron

Proof of concept for the **Build for Everyone Hackathon** (k-ID × Google, Oct 21 2026).

The player is a single electron travelling to a kid's bedroom lamp. Three stops teach
conductors vs. insulators, open vs. closed circuits, and resistance. Every solved stop
delivers watts that make the lamp brighter. The game is the same for everyone; a k-ID
style capability layer decides what each player gets by age and region, and Gemini
explains mistakes at that player's reading level.

| Age 6 · voice tutor | Age 10 · guided tutor | Age 15 · open tutor |
| --- | --- | --- |
| ![](docs/screenshots/age-6-voice-tutor.png) | ![](docs/screenshots/age-10-guided-tutor.png) | ![](docs/screenshots/age-15-open-tutor.png) |

## Run it in Google AI Studio

1. Open [AI Studio → Build](https://aistudio.google.com/apps).
2. Click the **+** in the prompt box and choose **Import from GitHub**.
3. Paste this repository's URL (branch `claude/focused-pascal-x2q55i` until merged) and click **Import repository**.
4. AI Studio detects the Vite + React project, injects your Gemini key as `process.env.API_KEY`, and runs it.

The app lives in `hackathon/be-the-electron/`. If AI Studio only detects projects at the
repository root, point it at a copy of this folder in its own repo, or in the Build editor
tell Gemini "the app is in hackathon/be-the-electron".

Without a key the app still runs with canned "offline" hints, so the demo never dead-ends.

## Run it locally

```bash
cd hackathon/be-the-electron
npm install
cp .env.local.example .env.local   # add your GEMINI_API_KEY
npm run dev                        # http://localhost:3000
```

## Demo script (60 seconds)

1. Start as **Age 6**: tap Rubber. The electron stops, shakes, and Spark *speaks* a one-line hint. No text input anywhere.
2. Switch to **Age 10** on the same stop: three gaps to fill, a coach that asks a guiding question, tappable follow-ups, sharing gated behind a parent.
3. Switch to **Age 15**: resistances shown in ohms, Ohm's law, open chat with the tutor, open sharing. Flip region to **DE** and watch sharing fall back to parent approval (consent age 16).
4. Finish the lamp stop. The bedroom reaches full brightness and the three component cards are complete.

## Architecture

```
index.tsx / App.tsx        game shell, progress + learner memory (localStorage)
capabilities.ts            CapabilityProvider interface, MockCapabilityProvider, policy table  ← swap in real k-ID here
prompts.ts                 persona per tutor mode, system/user prompt builders
gemini.ts                  Gemini 2.5 Flash hint engine (structured JSON) + offline fallback + Web Speech
components/
  WireStop / SwitchStop / LampStop   one mechanic each, three variants driven by caps.inputMode
  Tutor                              voice / guided / open faces of the same tutor
  Bedroom                            the lamp-brightness reward
  AgeSwitcher                        demo-only stand-in for k-ID age assurance
```

### Capability flags (what the app reads, never age directly)

| Flag | 5–7 | 8–12 | 13–17 |
| --- | --- | --- | --- |
| `inputMode` | `tap` | `build` | `calculate` |
| `tutorMode` | `voice` | `guided` | `open` |
| `sharing` | `none` | `parent-approved` | `open` (or `parent-approved` under the regional consent age) |
| `dataPolicy` | `minimal` | `consented` | `regional` |

Under `minimal`, the learner profile is never persisted and the Gemini prompt carries no history.

### Learner memory

A small JSON object the tutor is allowed to remember: `misconceptionsSeen`, `hintsUsed`,
`stopsCompleted`. It is injected into the system prompt (except under `minimal`) so the
tutor can say "remember how rubber blocked you?" at a later stop. Inspect it from the
"What the tutor remembers" panel.

## Build-day TODO

- [ ] Implement `KidCapabilityProvider` against the real k-ID SDK (morning reveal)
- [ ] Optional: Gemini TTS instead of browser speech for the voice persona
- [ ] Optional: power-plant stop (spin the turbine) as the opener
- [ ] Polish art; shapes are intentionally simple
