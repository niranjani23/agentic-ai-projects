import type { AgeBand, Capabilities, Region } from './types';

/**
 * The only thing the rest of the app depends on. On hackathon morning, implement
 * `KidCapabilityProvider` against the real k-ID SDK and swap it in App.tsx.
 */
export interface CapabilityProvider {
  getUserCapabilities(): Promise<Capabilities>;
}

/** Digital age of consent per region (simplified for the demo). */
const CONSENT_AGE: Record<Region, number> = { US: 13, DE: 16, UK: 13, BR: 12 };

const REPRESENTATIVE_AGE: Record<AgeBand, number> = { '5-7': 6, '8-12': 10, '13-17': 15 };

/** Policy table: the same age band can unlock different features in different regions. */
export function resolvePolicy(ageBand: AgeBand, region: Region): Capabilities {
  const age = REPRESENTATIVE_AGE[ageBand];
  const consentAge = CONSENT_AGE[region];
  const underConsentAge = age < consentAge;

  if (ageBand === '5-7') {
    return {
      ageBand, region,
      inputMode: 'tap',
      tutorMode: 'voice',
      sharing: 'none',
      dataPolicy: 'minimal',
      rationale: `Age ${age}: voice-only tutor, no free text leaves the device, no sharing.`,
    };
  }
  if (ageBand === '8-12') {
    return {
      ageBand, region,
      inputMode: 'build',
      tutorMode: 'guided',
      sharing: underConsentAge ? 'parent-approved' : 'open',
      dataPolicy: 'consented',
      rationale: `Age ${age} in ${region}: guided Q&A, sharing ${underConsentAge ? 'needs a parent' : 'allowed'} (consent age ${consentAge}).`,
    };
  }
  return {
    ageBand, region,
    inputMode: 'calculate',
    tutorMode: 'open',
    sharing: underConsentAge ? 'parent-approved' : 'open',
    dataPolicy: 'regional',
    rationale: `Age ${age} in ${region}: open chat, ${underConsentAge ? 'sharing still needs a parent' : 'full sharing'} (consent age ${consentAge}).`,
  };
}

/** Demo provider: the age switcher in the UI drives this. */
export class MockCapabilityProvider implements CapabilityProvider {
  constructor(private ageBand: AgeBand, private region: Region) {}
  async getUserCapabilities(): Promise<Capabilities> {
    await new Promise((r) => setTimeout(r, 250)); // feel like a network call
    return resolvePolicy(this.ageBand, this.region);
  }
}

/**
 * TODO (event morning): real adapter.
 * Expected shape: k-ID session → list of permissions per feature → map to Capabilities.
 * Keep the mapping here so no component ever imports k-ID directly.
 */
export class KidCapabilityProvider implements CapabilityProvider {
  async getUserCapabilities(): Promise<Capabilities> {
    throw new Error('KidCapabilityProvider not wired yet. Use MockCapabilityProvider for the demo.');
  }
}
