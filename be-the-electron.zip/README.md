# agentic-ai-projects

| Project | Folder | Notes |
| --- | --- | --- |
| ⚡ Be the Electron | [`hackathon/be-the-electron`](hackathon/be-the-electron) | Age-adaptive electricity game for the Build for Everyone Hackathon (k-ID × Google). Vite + React + Gemini. |
